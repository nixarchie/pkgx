#!/usr/bin/env bash
set -eu

. "$LIB/backend.sh"

backend_sync

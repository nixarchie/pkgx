##!/usr/bin/env bash

#fzf_args=(
#  --multi
#  --preview 'yay -Qi {1}'
#  --preview-label='alt-p: toggle description, alt-j/k: scroll, tab: multi-select'
#  --preview-label-pos='bottom'
#  --preview-window 'down:65%:wrap'
#  --bind 'alt-p:toggle-preview'
#  --bind 'alt-d:preview-half-page-down,alt-u:preview-half-page-up'
#  --bind 'alt-k:preview-up,alt-j:preview-down'
#  --color 'pointer:red,marker:red'
#)

#pkg_names=$(yay -Qqe | fzf "${fzf_args[@]}")

#if [[ -n "$pkg_names" ]]; then
#  # Convert newline-separated selections to space-separated for yay
#  echo "$pkg_names" | tr '\n' ' ' | xargs sudo pacman -Rns --noconfirm
#  omarchy-show-done
#fi

#!/usr/bin/env sh
set -eu

DIR="$(dirname "$0")"
. "$DIR/../lib/backend.sh"

[ "$#" -ge 1 ] || die "usage: pkgx rm <pkg> [pkg...]"

backend_rm "$@"
show_done